//
//  AnalysisPage.swift
//  TweetSense
//
//  Created by Vlad Munteanu on 2/15/20.
//  Copyright © 2020 Vlad Munteanu. All rights reserved.
//

import Foundation
import UIKit

struct AnalysisPage {
    let name: String
   // let photoUrl: String
   // var senseScore: Double
    let isUser: Bool
    
    let tweets: [Tweet]
    //Sentiment Score
    let sentimentScore: Double
    let magnitude: Double
   // let sentimentColor: UIColor
    
    //Values
    let valuesScores: [Int]
    //let valuesColor: UIColor

    //Emotion
    let toneScores: [Int]
   // let toneColor: UIColor
    
    //Social Tendencies
    let socialTendencies: [Int]
    //let socialColor: UIColor

    init(name:String, photoUrl:String, senseScore:Double, isUser:Bool, tweets:[Tweet], sentimentScore:Double, sentimentColor:UIColor, valuesScores:[Int], valuesColor:UIColor, toneScores:[Int], toneColor:UIColor, socialTendencies:[Int], socialColor:UIColor, magnitude:Double) {
        self.name = name
       
        self.isUser = isUser
        self.tweets = tweets
        self.sentimentScore = sentimentScore
     
        self.valuesScores = valuesScores
       
        self.toneScores = toneScores
       // self.toneColor = toneColor
        self.socialTendencies = socialTendencies
       // self.socialColor = socialColor
        self.magnitude = magnitude
    }
    
    
}


//    let analyticalScore: Int
//    let confidentScore: Int
//    let tenativeScore: Int
    
//    let fearScore: Int
//    let joyScore: Int
//    let disgustScore: Int
//    let angerScore: Int
//    let sadnessScore: Int

//    let agreeablenessScore: Int
//    let conscientiousnessScore: Int
//    let extroversionScore: Int
//    let emotionRangeScore: Int
//    let openessScore: Int
